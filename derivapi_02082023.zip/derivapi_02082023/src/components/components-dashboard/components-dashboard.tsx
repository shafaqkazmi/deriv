import { ComponentTradeBoard } from "../component-trade-board/component-trade-board";

export const ComponentDashbaord = () => <ComponentTradeBoard />;
